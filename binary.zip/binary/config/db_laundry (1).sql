-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Apr 2021 pada 05.40
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_laundry`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_detail_transaksi`
--

CREATE TABLE `tb_detail_transaksi` (
  `transaksi_id` char(4) NOT NULL,
  `pakaian_id` char(2) NOT NULL,
  `jumlah_pakaian` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_detail_transaksi`
--

INSERT INTO `tb_detail_transaksi` (`transaksi_id`, `pakaian_id`, `jumlah_pakaian`) VALUES
('1134', 'A2', 3),
('1134', 'A1', 8),
('1135', 'A3', 8),
('1136', 'A3', 8),
('1137', 'A1', 3),
('1138', 'Pi', 4),
('1138', 'A4', 3),
('1139', 'A1', 8),
('1140', 'A3', 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_outlet`
--

CREATE TABLE `tb_outlet` (
  `id_outlet` int(15) NOT NULL,
  `nama_outlet` varchar(35) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_outlet`
--

INSERT INTO `tb_outlet` (`id_outlet`, `nama_outlet`, `alamat`, `telp`) VALUES
(2, 'jaya laundry', 'jalan Srandakan km17', '087838405292'),
(4, 'iice laundry', 'jl ditempat', '908776626728');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pakaian`
--

CREATE TABLE `tb_pakaian` (
  `id_pakaian` char(2) NOT NULL,
  `jenis_pakaian` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_pakaian`
--

INSERT INTO `tb_pakaian` (`id_pakaian`, `jenis_pakaian`) VALUES
('A1', 'jaket'),
('A2', 'celana panjang'),
('A3', 'sarung'),
('A4', 'sajadah');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_paket`
--

CREATE TABLE `tb_paket` (
  `id_paket` int(15) NOT NULL,
  `outlet_id` int(15) NOT NULL,
  `jenis` enum('reguler','kilat') NOT NULL,
  `harga` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_paket`
--

INSERT INTO `tb_paket` (`id_paket`, `outlet_id`, `jenis`, `harga`) VALUES
(5, 2, 'reguler', 4000),
(6, 4, 'kilat', 8000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pelanggan`
--

CREATE TABLE `tb_pelanggan` (
  `id_pelanggan` int(15) NOT NULL,
  `nama_pelanggan` varchar(35) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(15) NOT NULL,
  `outlet_id` int(15) DEFAULT NULL,
  `jenis_langganan` enum('reguler','member') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_pelanggan`
--

INSERT INTO `tb_pelanggan` (`id_pelanggan`, `nama_pelanggan`, `alamat`, `telp`, `outlet_id`, `jenis_langganan`) VALUES
(1, 'arma', 'Bantul', '08665567564', 0, 'reguler'),
(8, 'pace', 'jalan ditempat', '08445541467', 0, 'member');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `id_transaksi` char(4) NOT NULL,
  `user_id` int(11) NOT NULL,
  `outlet_id` int(15) NOT NULL,
  `pelanggan_id` int(15) NOT NULL,
  `paket_id` int(11) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `tgl_selesai` date NOT NULL,
  `berat` double NOT NULL,
  `total_bayar` int(20) NOT NULL,
  `status_bayar` enum('belum','lunas') NOT NULL,
  `status_transaksi` enum('proses','selesai','diambil') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id_transaksi`, `user_id`, `outlet_id`, `pelanggan_id`, `paket_id`, `tgl_masuk`, `tgl_selesai`, `berat`, `total_bayar`, `status_bayar`, `status_transaksi`) VALUES
('1130', 8, 2, 1, 5, '2021-04-07', '2021-04-08', 4, 16000, 'lunas', 'diambil'),
('1131', 8, 4, 8, 6, '2021-04-07', '2021-04-07', 2, 10000, 'lunas', 'selesai'),
('1132', 8, 2, 1, 6, '2021-04-07', '2021-04-07', 4, 10000, 'belum', 'proses'),
('1133', 8, 2, 8, 6, '2021-04-07', '2021-04-07', 6, 48000, 'belum', 'proses'),
('1134', 8, 4, 8, 5, '2021-04-07', '2021-04-07', 5, 2000, 'belum', 'proses'),
('1135', 8, 4, 1, 5, '2021-04-07', '2021-04-07', 2, 8000, 'belum', 'proses'),
('1136', 8, 4, 8, 6, '2021-04-07', '2021-04-07', 3, 24000, 'belum', 'proses'),
('1137', 8, 4, 1, 5, '2021-04-08', '2021-04-08', 3, 12000, 'belum', 'proses'),
('1138', 8, 2, 8, 5, '2021-04-08', '2021-04-08', 4, 24000, 'belum', 'proses'),
('1139', 8, 2, 1, 5, '2021-04-08', '2021-04-08', 4, 16000, 'belum', 'proses'),
('1140', 8, 4, 1, 5, '2021-04-08', '2021-04-08', 2, 8000, 'belum', 'proses');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(15) NOT NULL,
  `nama_user` varchar(35) NOT NULL,
  `username` varchar(35) NOT NULL,
  `password` varchar(35) NOT NULL,
  `outlet_id` int(15) DEFAULT NULL,
  `level` enum('admin','kasir','owner') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nama_user`, `username`, `password`, `outlet_id`, `level`) VALUES
(8, 'Zeus', 'admin', '21232f297a57a5a743894a0e4a801fc3', NULL, 'admin'),
(9, 'Troy', 'kasir', 'c7911af3adbd12a035b289556d96470a', NULL, 'kasir'),
(10, 'jrx', 'owner', '72122ce96bfec66e2396d2e25225d70a', NULL, 'owner'),
(11, 'jos', 'siap', '6f7f3b0fb100c0b0fb21a0287cd72f7b', NULL, 'kasir'),
(13, 'hiho', 'kbjbj', '4b53919e647386649c089a6515de152a', NULL, 'kasir');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_detail_transaksi`
--
ALTER TABLE `tb_detail_transaksi`
  ADD KEY `transaksi_id` (`transaksi_id`),
  ADD KEY `pakaian_id` (`pakaian_id`);

--
-- Indeks untuk tabel `tb_outlet`
--
ALTER TABLE `tb_outlet`
  ADD PRIMARY KEY (`id_outlet`);

--
-- Indeks untuk tabel `tb_pakaian`
--
ALTER TABLE `tb_pakaian`
  ADD PRIMARY KEY (`id_pakaian`);

--
-- Indeks untuk tabel `tb_paket`
--
ALTER TABLE `tb_paket`
  ADD PRIMARY KEY (`id_paket`),
  ADD KEY `id_outlet` (`outlet_id`);

--
-- Indeks untuk tabel `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`),
  ADD KEY `id_outlet` (`outlet_id`);

--
-- Indeks untuk tabel `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `paket_id` (`paket_id`),
  ADD KEY `pelanggan_id` (`pelanggan_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_outlet` (`outlet_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_outlet`
--
ALTER TABLE `tb_outlet`
  MODIFY `id_outlet` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `tb_paket`
--
ALTER TABLE `tb_paket`
  MODIFY `id_paket` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  MODIFY `id_pelanggan` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tb_paket`
--
ALTER TABLE `tb_paket`
  ADD CONSTRAINT `tb_paket_ibfk_1` FOREIGN KEY (`outlet_id`) REFERENCES `tb_outlet` (`id_outlet`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD CONSTRAINT `tb_user_ibfk_1` FOREIGN KEY (`outlet_id`) REFERENCES `tb_outlet` (`id_outlet`) ON DELETE SET NULL ON UPDATE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
