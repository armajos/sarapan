<?php  
session_start();
include 'config/koneksi.php';
$username = $_POST['username'];
$password = md5($_POST['password']);
$query	  = "SELECT * FROM tb_user WHERE username='$username' AND password='$password'";
$row	  = mysqli_query($conn,$query);
$data     = mysqli_fetch_assoc($row);
$cek      = mysqli_num_rows($row);

if ($cek > 0) {
	if ($data['level'] == 'admin') {
		$_SESSION['level'] = 'admin';
		$_SESSION['username'] = $data['username'];
		$_SESSION['user_id'] = $data['id_user'];
		$_SESSION['id_outlet'] = $data['id_outlet'];
		header('location:admin');
	}elseif ($data['level'] == 'kasir') {
		$_SESSION['level'] = 'kasir';
		$_SESSION['username'] = $data['username'];
		$_SESSION['user_id'] = $data['id_user'];
		$_SESSION['id_outlet'] = $data['id_outlet'];
		header('location:kasir');
	}elseif ($data['level'] == 'owner') {
		$_SESSION['username'] = 'owner';
		$_SESSION['username'] = $data['username'];
		$_SESSION['user_id'] = $data['id_user'];
		$_SESSION['id_outlet'] = $data['id_outlet'];
		header('location:owner');
	}
}else{
	$psn = "Username atau password anda salah";
	header('location:index.php?psn='.$psn);
}
?>