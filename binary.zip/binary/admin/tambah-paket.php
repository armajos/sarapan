<?php  
$nama = 'Tambah Paket';
require 'fungsi.php';
require 'header.php';

$query = 'SELECT * FROM tb_outlet';
$data  = data($conn,$query);

if(isset($_POST['simpan'])){
	$jenis      = $_POST['jenis'];
	$harga      = $_POST['harga'];
	$outlet_id  = $_POST['outlet_id'];

	$query = "INSERT INTO tb_paket (jenis,harga,outlet_id) values ('$jenis','$harga','$outlet_id')";

	$execute = sukses($conn,$query);
	if($execute = 1){
		$_SESSION['pesan'] = "Tambah Data Paket Berhasil";
		header('Location: paket.php');
	}else{
		$_SESSION['pesan2'] = "Tambah Data Paket Gagal";
		header('Location: paket.php');
	}
}
?>
<div id="page-wrapper" >
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">
				<h2><?= $nama ?></h2>
			</div>
		</div>
		<!-- /. ROW  -->
		<hr />
		<div class="row">
			<div class="col-md-12">
				<div class="white-box">
					<form method="post" action="">
						<div class="form-group">
							<label>Harga</label>
							<input type="text" name="harga" class="form-control">
						</div>
						<div class="form-group">
							<label>Pilih Outlet</label>
							<select name="outlet_id" class="form-control">
								<option read-only value="">Pilih Outlet</option>
								<?php foreach ($data as $outlet): ?>
									<option value="<?= $outlet['id_outlet'] ?>"><?= $outlet['nama_outlet']; ?></option>
								<?php endforeach ?>
							</select>
						</div>
						<div class="form-group">
							<label>Jenis Paket</label>
							<select name="jenis" class="form-control">
								<option selected="">Pilih Paket</option>
								<option value="reguler">reguler</option>
								<option value="kilat">kilat</option>
							</select>
						</div>
						<div class="text-right">
							<button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
						</div>
					</form><br><br>
						<div class="col-md-6">
						<table class="table" border="1">
							<thead>
								<tr class="text-center">
									<th>Paket Reguler</th>
									<th>Paket Kilat</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Rp4.000</td>
									<td>Rp8.000</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

	</div>
	<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>