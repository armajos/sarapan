<?php  
$nama = 'Tambah Pelanggan';
require 'fungsi.php';
require 'header.php';
$outlet = data($conn,'SELECT * FROM tb_outlet');

if(isset($_POST['simpan'])){
  $nama_pelanggan  = $_POST['nama_pelanggan'];
  $alamat          = $_POST['alamat'];
  $telepon         = $_POST['telp'];
  $jenis_langganan = $_POST['jenis_langganan'];

  $query = "INSERT INTO tb_pelanggan (nama_pelanggan,alamat,telp,jenis_langganan) values ('$nama_pelanggan','$alamat','$telepon','$jenis_langganan')";

  $execute = sukses($conn,$query);
  if($execute == 1){
    $_SESSION['pesan'] = "Tambah Data Pelanggan Berhasil";
    header('Location: pelanggan.php');
  }else{
    $_SESSION['pesan2'] = "Tambah Data Pelanggan Gagal";
    header('Location: pelanggan.php');
  }
}
?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2><?= $nama ?></h2>
     </div>
   </div>
   <!-- /. ROW  -->
   <hr />
   <div class="row">
       <div class="col-md-12">
           <div class="white-box">
                <form method="post" action="">
              <div class="form-group">
                <label>Nama Pelanggan</label>
                <input type="text" name="nama_pelanggan" class="form-control">
              </div>
              <div class="form-group">
                <label>Alamat</label>
                <input type="text" name="alamat" class="form-control">
              </div>
              <div class="form-group">
                <label>Nomor Telepon</label>
                <input type="text" name="telp" class="form-control">
              </div>
              <div class="form-group">
                <label>Jenis Langganan</label>
                <select name="jenis_langganan" class="form-control">
                  <option selected="">Pilih Langganan</option>
                  <option value="reguler">reguler</option>
                  <option value="member">member</option>
                </select>
              </div>
              <div class="text-right">
                <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
              </div>
            </form>
            </div>
       </div>
   </div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>