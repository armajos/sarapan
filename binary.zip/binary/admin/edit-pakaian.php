<?php 
$nama = 'Edit Pakaian';
require 'fungsi.php';
require 'header.php';


$id_pakaian = $_GET['id'];
$queryedit = "SELECT * FROM tb_pakaian WHERE id_pakaian = '$id_pakaian'";
$edit = ambilsatubaris($conn,$queryedit);

if(isset($_POST['simpan'])){
    $jenis_pakaian  = $_POST['jenis_pakaian'];
    $jumlah = $_POST['jumlah'];
    $query = "UPDATE tb_pakaian SET jenis_pakaian = '$jenis_pakaian' WHERE id_pakaian = '$id_pakaian'";

    $execute = sukses($conn,$query);
    if($execute == 1){
        $_SESSION['pesan'] = "Edit Data Pakaian Berhasil";
        header('Location: pakaian.php');
    }else{
        $_SESSION['pesan2'] = "Edit Data Pakaian Gagal";
        header('Location: pakaian.php');
    }
}

?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
         <h2><?= $nama ?></h2>
     </div>
 </div>
 <!-- /. ROW  -->
 <hr />
 <div class="row">
   <div class="col-md-12">
     <div class="white-box">
        <form method="post" action="">
            <div class="form-group">
                <label>Jenis Pakaian</label>
                <input type="text" name="jenis_pakaian" class="form-control" value="<?= $edit['jenis_pakaian'] ?>">
            </div>
        <div class="text-right">
            <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div>
</div>
</div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>