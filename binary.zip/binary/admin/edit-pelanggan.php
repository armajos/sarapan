<?php 
$nama = 'Edit Pelanggan';
require 'fungsi.php';
require 'header.php';

$jenis_langganan = ['reguler','member'];

$id_pelanggan = $_GET['id'];
$queryedit = "SELECT * FROM tb_pelanggan WHERE id_pelanggan = '$id_pelanggan'";
$edit = ambilsatubaris($conn,$queryedit);

if(isset($_POST['simpan'])){
    $nama_pelanggan  = $_POST['nama_pelanggan'];
    $alamat  		 = $_POST['alamat'];
    $telp 			 = $_POST['telp'];
    $jenis_langganan = $_POST['jenis_langganan'];
    $query = "UPDATE tb_pelanggan SET nama_pelanggan = '$nama_pelanggan' , alamat = '$alamat' , telp = '$telp', jenis_langganan = '$jenis_langganan' WHERE id_pelanggan = '$id_pelanggan'";

    $execute = sukses($conn,$query);
    if($execute == 1){
        $_SESSION['pesan'] = "Edit Data Pelanggan Berhasil";
        header('Location: pelanggan.php');
    }else{
        $_SESSION['pesan2'] = "Edit Data Pelanggan Gagal";
        header('Location: pelanggan.php');
    }
}

?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
         <h2><?= $nama ?></h2>
     </div>
 </div>
 <!-- /. ROW  -->
 <hr />
 <div class="row">
   <div class="col-md-12">
     <div class="white-box">
        <form method="post" action="">
            <div class="form-group">
                <label>Nama Pelanggan</label>
                <input type="text" name="nama_pelanggan" class="form-control" value="<?= $edit['nama_pelanggan'] ?>">
            </div>
            <div class="form-group">
                <label>Alamat</label>
                <input type="text" name="alamat" class="form-control" value="<?= $edit['alamat'] ?>">
            </div>
            <div class="form-group">
                <label>Nomor Telepon</label>
                <input type="text" name="telp" class="form-control" value="<?= $edit['telp'] ?>">
            </div>
        </div>
        <div class="form-group">
            <label>Jenis Langganan</label>
            <select name="jenis_langganan" class="form-control">
                <?php foreach ($jenis_langganan as $key): ?>
                    <?php if ($key == $edit['jenis_langganan']): ?>
                        <option value="<?= $key ?>" selected><?= $key ?></option>    
                    <?php endif ?>
                    <option value="<?= $key ?>"><?= ucfirst($key) ?></option>
                <?php endforeach ?>
            </select>
        </div>
        <div class="text-right">
            <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div>
</div>
</div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>