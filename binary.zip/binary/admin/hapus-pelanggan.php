<?php 
require 'fungsi.php';
$sql = "DELETE FROM tb_pelanggan WHERE id_pelanggan= " . $_GET['id'];
$exe = mysqli_query($conn,$sql);

if($exe){
        $_SESSION['pesan'] = "Hapus Data Pelanggan Berhasil";
        header('Location: pelanggan.php');
    }else{
        $_SESSION['pesan2'] = "Hapus Data Pelanggan Gagal";
        header('Location: pelanggan.php');
    }
 ?>

