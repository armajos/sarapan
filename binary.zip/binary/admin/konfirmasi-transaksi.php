<?php
$nama = 'Konfirmasi Transaksi';
require 'fungsi.php';
require 'header.php';
$query = "SELECT tb_transaksi.*,tb_pelanggan.nama_pelanggan FROM tb_transaksi INNER JOIN tb_pelanggan ON tb_pelanggan.id_pelanggan = tb_transaksi.pelanggan_id WHERE tb_transaksi.status_bayar='belum'";
$data = data($conn,$query);
?> 
<div id="page-wrapper" >
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">
				<div class="col-md-6"><h2><?= $nama ?></h2></div>
        <div class="col-md-6 text-right"><h2><a href="transaksi.php"><i class="fa fa-arrow-left" title="kembali" style="color: red;"></i></a></h2></div>
			</div>
		</div>
		<!-- /. ROW  -->
		<hr />
		<div class="row">
			<div class="col-md-12">
				<!-- Advanced Tables -->
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover" id="dataTables-example">
								<thead class="thead-dark">
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Invoice</th>
                                <th class="text-center">Pelanggan</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Total Harga</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (is_array($data)): ?>
                            <?php $no=1; foreach($data as $transaksi): ?>
                                <tr style="text-align: center;">
                                    <td><?= $no++; ?></td>
                                    <td><?= $transaksi['id_transaksi'] ?></td>
                                    <td><?= $transaksi['nama_pelanggan'] ?></td>
                                    <td><?= $transaksi['status_bayar'] ?></td>
                                    <td><?= $transaksi['total_bayar'] ?></td>
                                    <td align="center">
                                          <a href="bayar.php?id=<?= $transaksi['id_transaksi']; ?>" data-toggle="tooltip" data-placement="bottom" title="Pilih" class="btn btn-primary btn-block">Pilih</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif ?>
                        </tbody>
								</table>
							</div>

						</div>
					</div>
					<!--End Advanced Tables -->
				</div>
			</div>

		</div>
		<!-- /. PAGE INNER  -->
	</div>
	<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>