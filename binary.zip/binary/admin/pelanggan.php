<?php 
$nama = 'Pelanggan';
require 'fungsi.php';
require 'header.php'; 

// $query = 'SELECT tb_pelanggan.*, tb_outlet.nama_outlet FROM tb_outlet LEFT JOIN tb_pelanggan ON tb_pelanggan.outlet_id = tb_outlet.id_outlet';
$query = 'SELECT * FROM tb_pelanggan';

$data = data($conn,$query);
$no=1;
?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
        <h2><?= $nama ?></h2>

      </div>
    </div>
    <!-- /. ROW  -->
    <hr />
    <?php 
    if (isset($_SESSION['pesan'])) {
      echo "<div class='alert alert-success' role='alert'>";
      echo $_SESSION['pesan'];
      unset($_SESSION['pesan']);
      echo "</div>";
      echo "<br/>";
    }elseif (isset($_SESSION['pesan2'])) {
      echo "<div class='alert alert-danger' role='alert'>";
      echo $_SESSION['pesan2'];
      unset($_SESSION['pesan2']);
      echo "</div>";
      echo "<br/>";
    }
    ?>
    <div class="row">
      <div class="col-md-12">
        <a href="tambah-pelanggan.php" class="btn btn-primary btn-block"><i class="fa fa-plus fa-lg"></i></a>
        <!-- Advanced Tables -->
        <div class="panel panel-default">
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover" id="dataTables-example">
               <thead>                                 
                <tr>
                  <th class="text-center">No</th>
                  <th>Nama Pelanggan</th>
                  <th>Alamat</th>
                  <th>Nomor Telepon</th>
                  <!-- <th>Nama Outlet</th> -->
                  <th>Jenis Langanan</th>
                  <th class="text-center">Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                foreach ($data as $pelanggan) :
                  ?>                       
                  <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td><?= $pelanggan['nama_pelanggan'] ?></td>
                    <td><?= $pelanggan['alamat'] ?></td>
                    <td><?= $pelanggan['telp'] ?></td>
                    <td><?= $pelanggan['jenis_langganan'] ?></td>
                    <td class="text-center">
                      <div class="btn-group" role="group" aria-label="Basic example">
                        <a href="edit-pelanggan.php?id=<?= $pelanggan['id_pelanggan']; ?>" data-toggle="tooltip" data-placement="bottom" title="Edit" class="btn btn-success"><i class="fa fa-edit"></i></a>
                        <a href=hapus-pelanggan.php?id=<?= $pelanggan['id_pelanggan']; ?> onclick="return confirm('Ingin hapus data ? ');" data-toggle="tooltip" data-placement="bottom" title="Hapus" class="btn btn-warning"><i class="fa fa-ban"></i></a>
                      </div>
                    </td>
                  </tr>
                  <?php
                endforeach;  
                ?>
              </tbody>
              </table>
            </div>

          </div>
        </div>
        <!--End Advanced Tables -->
      </div>
    </div>

  </div>
  <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>