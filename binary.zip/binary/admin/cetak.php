<?php  
$nama = 'Cetak';
require 'fungsi.php';
$query = "SELECT tb_transaksi.*,tb_pelanggan.nama_pelanggan FROM tb_transaksi INNER JOIN tb_pelanggan ON tb_pelanggan.id_pelanggan = tb_transaksi.pelanggan_id ";
$data = data($conn,$query);
$no =1
?>
<!DOCTYPE html>
<html>
<head>
	<title><?= $nama ?></title>
</head>
<body>
	<center>
	<h2>Cetak Data Laporan</h2>
	</center>
	<table border="1">
		<thead>
			<tr>
				<th class="text-center">No</th>
				<th>Invoice</th>
				<th>Nama Pelanggan</th>
				<th>Tgl Transaksi</th>
				<th>Berat</th>
				<th>Status Bayar</th>
				<th>Status Transaksi</th>
				<th>Total Bayar</th>
			</tr>
		</thead>
		<tbody>
			<?php if (is_array($data)): ?>
                <?php $no=1; foreach($data as $transaksi): ?>
                <tr>
                  <td class="text-center"><?= $no++; ?></td>
                  <td><?= $transaksi['id_transaksi'] ?></td>
                  <td><?= $transaksi['nama_pelanggan'] ?></td>
                  <td><?= $transaksi['tgl_masuk'] ?></td>
                  <td><?= $transaksi['berat'] ?>Kg</td>
                  <td><?= $transaksi['status_bayar'] ?></td>
                  <td><?= $transaksi['status_transaksi'] ?></td>
                  <td><b>Rp.</b><?= $transaksi['total_bayar'] ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif ?>
		</tbody>
	</table>
	<script type="text/javascript">
		window.print();
	</script>
</body>
</html>