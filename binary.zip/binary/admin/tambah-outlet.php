<?php 
$nama = 'Tambah Outlet';
require 'fungsi.php';
require 'header.php';

if (isset($_POST['simpan'])) {
  $namaout = $_POST['nama_outlet'];
  $alamat  = $_POST['alamat'];
  $telepon = $_POST['telp'];

  $query = "INSERT INTO tb_outlet (nama_outlet,alamat,telp) values ('$namaout','$alamat','$telepon')";

  $ex = sukses($conn,$query);
  if($ex = 1){
    $_SESSION['pesan'] = "Tambah Data Outlet Berhasil";
    header('Location: outlet.php');
  }else{
    $_SESSION['pesan'] = "Tambah Data Outlet Gagal";
  }
}

?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2><?= $nama ?></h2>
     </div>
   </div>
   <!-- /. ROW  -->
   <hr />
   <div class="row">
  <div class="col-md-12">
    <div class="white-box">
      <form method="post" action="">
        <div class="form-group">
          <label>Nama Outlet</label>
          <input type="text" name="nama_outlet" class="form-control">
        </div>
        <div class="form-group">
          <label>Alamat</label>
          <input type="text" name="alamat" class="form-control">
        </div>
        <div class="form-group">
          <label>Telepon</label>
          <input type="text" name="telp" class="form-control">
        </div>
        <div class="text-right">
          <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>