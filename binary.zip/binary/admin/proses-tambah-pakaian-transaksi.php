<?php 
require 'fungsi.php';

  $transaksi_id = $_POST["transaksi_id"];
  $pakaian_id = $_POST["pakaian_id"];
  $jumlah = $_POST["jumlah"];

  $query = "INSERT INTO tb_detail_transaksi (transaksi_id,pakaian_id,jumlah_pakaian) values ('$transaksi_id','$pakaian_id','$jumlah')";
  $hasil = sukses($conn,$query);
  if($hasil == 1){
        $_SESSION['pesan'] = "Tambah Data Pakaian Berhasil";
        header('Location: tambah-transaksi.php');
    }else{
        $_SESSION['pesan2'] = "Tambah Data Pakaian Gagal";
        header('Location: tambah-transaksi.php');
    }
?>
<!-- $data = data($conn,'SELECT tb_detail_transaksi.*, tb_pakaian.jenis_pakaian FROM tb_pakaian LEFT JOIN tb_detail_pakaian ON tb_detail_pakaian.pakaian_id = tb_pakaian.id_pakaian'); -->