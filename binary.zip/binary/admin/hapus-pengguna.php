<?php 
require 'fungsi.php';
$sql = "DELETE FROM tb_user WHERE id_user = " . $_GET['id'];
$exe = mysqli_query($conn,$sql);

if($exe){
        $_SESSION['pesan'] = "Hapus Data Pengguna Berhasil";
        header('Location: pengguna.php');
    }else{
        $_SESSION['pesan2'] = "Hapus Data Pengguna Gagal";
    }
 ?>

