<?php  
$nama = 'Pilih Pelanggan';
require'fungsi.php';
require 'header.php';

$query = 'SELECT * FROM tb_pelanggan';
$data  = data($conn,$query);
$no = 1;
?>

</tbody>
<div id="page-wrapper" >
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">
				<h2><?= $nama ?></h2>

			</div>
		</div>
		<!-- /. ROW  -->
		<hr />
		<div class="row">
			<div class="col-md-12">
				<!-- Advanced Tables -->
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="table-responsive">
							<table class="table table-striped table-bordered table-hover" id="dataTables-example">
								<thead>                                 
									<tr>
										<th class="text-center">No</th>
										<th>Nama Pelanggan</th>
										<th>Alamat</th>
										<th>Nomor Telepon</th>
										<th>Jenis Langanan</th>
										<th width="15%">Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php
									foreach ($data as $pelanggan) :
										?>                       
										<tr>
											<td class="text-center"><?= $no++ ?></td>
											<td><?= $pelanggan['nama_pelanggan'] ?></td>
											<td><?= $pelanggan['alamat'] ?></td>
											<td><?= $pelanggan['telp'] ?></td>
											<td><?= $pelanggan['jenis_langganan'] ?></td>
											<td>
												<div class="btn-group" role="group" aria-label="Basic example">
													<a href="tambah-transaksi.php?id=<?= $pelanggan['id_pelanggan']; ?>" data-toggle="tooltip" data-placement="bottom" title="Pilih" class="btn btn-primary btn-block">Pilih</a>
												</div>
											</td>
										</tr>
										<?php
									endforeach;  
									?>
								</table>
							</div>

						</div>
					</div>
					<!--End Advanced Tables -->
				</div>
			</div>

		</div>
		<!-- /. PAGE INNER  -->
	</div>
	<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>