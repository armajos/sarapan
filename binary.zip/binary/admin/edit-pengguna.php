<?php  
$nama = 'Edit Pengguna';
require 'fungsi.php';
require 'header.php';
$level = ['admin','kasir','owner'];

$id_user = $_GET['id'];
$queryedit = "SELECT * FROM tb_user WHERE id_user = '$id_user'";
$edit = ambilsatubaris($conn,$queryedit);

if(isset($_POST['simpan'])){
  $namaus     = $_POST['nama_user'];
  $username = $_POST['username'];
  $level     = $_POST['level'];
  if($_POST['password'] != null || $_POST['password'] == ''){
    $password     = md5($_POST['password']);
    $query = "UPDATE tb_user SET nama_user = '$namaus' , username = '$username' , level = '$level' , password ='$password' WHERE id_user = '$id_user'";    
  }else{
    $query = "UPDATE tb_user SET nama_user = '$namaus' , username = '$username' , level = '$level' WHERE id_user = '$id_user'";
  }


  $execute = sukses($conn,$query);
  if($execute == 1){
    $_SESSION['pesan'] = "Edit Data Pengguna Berhasil";
    header('Location: pengguna.php');
  }else{
    $_SESSION['pesan'] = "Edit Data Pengguna Gagal";
  }
}
?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2><?= $nama ?></h2>
     </div>
   </div>
   <!-- /. ROW  -->
   <hr />
   <div class="row">
     <div class="col-md-12">
       <div class="white-box">
        <form method="post" action="">
          <div class="form-group">
            <label>Nama Pengguna</label>
            <input type="text" name="nama_user" class="form-control" value="<?= $edit['nama_user'] ?>">
          </div>
          <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" value="<?= $edit['username'] ?>">
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="text" name="password" class="form-control" value="<?= $edit['password'] ?>">
          </div>
          <div class="form-group">
            <label>Level</label>
            <select name="level" class="form-control">
              <?php foreach ($level as $key): ?>
                <?php if ($key == $edit['level']): ?>
                  <option value="<?= $key ?>" selected><?= $key ?></option>    
                <?php endif ?>
                <option value="<?= $key ?>"><?= ucfirst($key) ?></option>
              <?php endforeach ?>
            </select>
          </div>
          <div class="text-right">
            <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>