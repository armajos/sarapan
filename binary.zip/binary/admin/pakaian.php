<?php 
$nama = 'Pakaian';
require 'fungsi.php';
require 'header.php'; 

$query = 'SELECT * FROM tb_pakaian ORDER BY id_pakaian';
$data = data($conn,$query);
$no=1;
?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
        <h2><?= $nama ?></h2>

      </div>
    </div>
    <!-- /. ROW  -->
    <hr />
    <?php 
    if (isset($_SESSION['pesan'])) {
      echo "<div class='alert alert-success' role='alert'>";
      echo $_SESSION['pesan'];
      unset($_SESSION['pesan']);
      echo "</div>";
      echo "<br/>";
    }elseif (isset($_SESSION['pesan2'])) {
      echo "<div class='alert alert-danger' role='alert'>";
      echo $_SESSION['pesan2'];
      unset($_SESSION['pesan2']);
      echo "</div>";
      echo "<br/>";
    }
    ?>
    <div class="row">
      <div class="col-md-12">
        <a href="tambah-pakaian.php" class="btn btn-primary btn-block"><i class="fa fa-plus fa-lg"></i></a>
        <!-- Advanced Tables -->
        <div class="panel panel-default">
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover" id="dataTables-example">
               <thead>                                 
                <tr>
                  <th class="text-center">Kode Pakaian</th>
                  <th class="text-center">Jenis Pakaian</th>
                  <th class="text-center">Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                foreach ($data as $pakaian) :
                  ?>                       
                  <tr>
                    <td class="text-center"><?= $pakaian['id_pakaian'] ?></td>
                    <td class="text-center"><?= $pakaian['jenis_pakaian'] ?></td>
                    <td class="text-center">
                      <div class="btn-group" role="group" aria-label="Basic example">
                        <a href="edit-pakaian.php?id=<?= $pakaian['id_pakaian']; ?>" data-toggle="tooltip" data-placement="bottom" title="Edit" class="btn btn-success"><i class="fa fa-edit"></i></a>
                        <a href=hapus-pakaian.php?id=<?= $pakaian['id_pakaian']; ?> onclick="return confirm('Ingin hapus data ? ');" data-toggle="tooltip" data-placement="bottom" title="Hapus" class="btn btn-warning"><i class="fa fa-ban"></i></a>
                      </div>
                    </td>
                  </tr>
                  <?php
                endforeach;  
                ?>
              </tbody>
              </table>
            </div>

          </div>
        </div>
        <!--End Advanced Tables -->
      </div>
    </div>

  </div>
  <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>