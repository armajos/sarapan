<?php 
$nama = 'Data Laporan';
require 'fungsi.php';
require 'header.php';

if (isset($_POST['submit'])) {
  $date1 = $_POST['date1'];
  $date2 = $_POST['date2'];

  if (!empty($date1) && !empty($date2)) {
    // perintah tampil data berdasarkan range tanggal
    $q = mysqli_query($conn, "SELECT tb_transaksi.*,tb_pelanggan.nama_pelanggan FROM tb_transaksi INNER JOIN tb_pelanggan ON tb_pelanggan.id_pelanggan = tb_transaksi.pelanggan_id WHERE tgl_masuk BETWEEN '$date1' and '$date2'"); 
  } else {
    // perintah tampil semua data
    $q = mysqli_query($conn, "SELECT tb_transaksi.*,tb_pelanggan.nama_pelanggan FROM tb_transaksi INNER JOIN tb_pelanggan ON tb_pelanggan.id_pelanggan = tb_transaksi.pelanggan_id "); 
  } 
} else {
  // perintah tampil semua data
  $q = mysqli_query($conn, "SELECT tb_transaksi.*,tb_pelanggan.nama_pelanggan FROM tb_transaksi INNER JOIN tb_pelanggan ON tb_pelanggan.id_pelanggan = tb_transaksi.pelanggan_id ");
}

?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
        <div class="col-md-6"><h2><?= $nama ?></h2></div>
        <div class="col-md-6 text-right"><h2><a href="cetak.php" target="_blank"><i class="fa fa-print" title="cetak"></i></a></h2></div>
      </div>
    </div>
    <!-- /. ROW  -->
    <hr />
    <div class="row">
      <div class=" col-md-12">
        <form method="POST" action="" class="form-inline mt-3 text-center">
          <label for="date1">Tanggal mulai&nbsp;</label>
          <input type="date" name="date1" id="date1" class="form-control" required>
          <label for="date2">sampai&nbsp;</label>
          <input type="date" name="date2" id="date2" class="form-control" required>
          <button type="submit" name="submit" class="btn btn-primary">Cari</button>
        </form>
      </div>
      <div class="col-md-12">
        <!-- Advanced Tables -->
        <div class="panel panel-default">
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>                                 
                  <tr>
                    <th class="text-center">No</th>
                    <th>Invoice</th>
                    <th>Nama Pelanggan</th>
                    <th>Tgl Transaksi</th>
                    <th>Berat</th>
                    <th>Status Bayar</th>
                    <th>Status Transaksi</th>
                    <th>Total Bayar</th>
                    <!-- <th class="text-center">Aksi</th> -->
                  </tr>
                </thead>
                <tbody>
                  <?php

                  $no = 1;

                  while ($r = $q->fetch_assoc()) {
                    ?>

                    <tr>

                      <td class="text-center"><?= $no++; ?></td>
                      <td><?= $r['id_transaksi'] ?></td>
                      <td><?= $r['nama_pelanggan'] ?></td>
                      <td><?= date('d-M-Y', strtotime($r['tgl_masuk'])) ?></td>
                      <td><?= $r['berat'] ?></td>
                      <td><?= $r['status_bayar'] ?></td>
                      <td><?= $r['status_transaksi'] ?></td>
                      <td><b>Rp.</b><?= $r['total_bayar'] ?></td>
                      <!-- <td align="center">
                        <a href="detail-transaksi.php?id=<?= $r['id_transaksi']; ?>" data-toggle="tooltip" data-placement="bottom" title="Edit" class="btn btn-success btn-block">Detail</a>
                      </td> -->
                    </tr>

                    <?php     
                  }
                  ?>
                </tbody>
              </table>
            </div>

          </div>
        </div>
        <!--End Advanced Tables -->
      </div>
    </div>

  </div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>