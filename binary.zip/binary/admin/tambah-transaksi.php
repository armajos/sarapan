<?php  
$nama = 'Tambah Transaksi';
require 'fungsi.php';
require 'header.php';
$tgl_masuk = date('Y-m-d');
$tgl_selesai = date('Y-m-d');
$user_id = $_SESSION['user_id'];
$outlet = data($conn,'SELECT * FROM tb_outlet');
$paket = data($conn,'SELECT * FROM tb_paket');
$pelanggan = data($conn,'SELECT * FROM tb_pelanggan');

if(isset($_POST['simpan'])){
  $berat  = $_POST['berat'];
  $transaksi_id       = $_POST['transaksi_id'];
  $outlet_id       = $_POST['outlet_id'];
  $pelanggan_id       = $_POST['pelanggan_id'];
  $paket_id       = $_POST['paket_id'];

  $hargapaket = ambilsatubaris($conn,'SELECT harga from tb_paket WHERE id_paket = ' . $paket_id);
  $total_harga = $hargapaket['harga'] * $berat;


  $query = "INSERT INTO tb_transaksi (tgl_masuk,tgl_selesai,berat,total_bayar,status_bayar,status_transaksi,id_transaksi,user_id,outlet_id,pelanggan_id,paket_id) values ('$tgl_masuk','$tgl_selesai','$berat','$total_harga','belum','proses','$transaksi_id','$user_id','$outlet_id','$pelanggan_id','$paket_id')";

  $execute = sukses($conn,$query);
  if($execute == 1){
    $_SESSION['pesan'] = "Tambah Data Transaksi Berhasil";
    header('Location: transaksi.php');
  }else{
    $_SESSION['pesan2'] = "Tambah Data Transaksi Gagal";
    header('Location: transaksi.php');
  }
}
?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2><?= $nama ?></h2>
     </div>
   </div>
   <!-- /. ROW  -->
   <hr />
   <?php 
    if (isset($_SESSION['pesan'])) {
      echo "<div class='alert alert-success' role='alert'>";
      echo $_SESSION['pesan'];
      unset($_SESSION['pesan']);
      echo "</div>";
      echo "<br/>";
    }elseif (isset($_SESSION['pesan2'])) {
      echo "<div class='alert alert-danger' role='alert'>";
      echo $_SESSION['pesan2'];
      unset($_SESSION['pesan2']);
      echo "</div>";
      echo "<br/>";
    }
    ?>
   <div class="row">
     <div class="col-md-6">
       <div class="white-box">
        <form method="post" action="">
          <div class="form-group">
            <?php
            $sql = mysqli_query($conn, "SELECT id_transaksi FROM tb_transaksi ORDER BY id_transaksi Desc LIMIT 1");
            while ($hasil = mysqli_fetch_array($sql)){
              $na = $hasil['id_transaksi'];
            }
            ?>
            <label>Invoice</label>
            <input type="text" class="form-control" name="transaksi_id" value="<?= $na + 1;  ?>" readonly>
          </div>
          <div class="form-group">
            <label>Nama Outlet</label>
            <select name="outlet_id" class="form-control">
              <option selected="">Pilih Outlet</option>
              <?php foreach ($outlet as $key): ?>
                <option value="<?= $key['id_outlet'] ?>"><?= $key['nama_outlet'] ?></option>
              <?php endforeach ?>
            </select>
          </div>
          <div class="form-group">
            <label>Pilih Pelanggan</label>
            <select name="pelanggan_id" class="form-control">
              <option selected="">Pilih Pelanggan</option>
              <?php foreach ($pelanggan as $key): ?>
                <option value="<?= $key['id_pelanggan'] ?>"><?= $key['nama_pelanggan'] ?></option>
              <?php endforeach ?>
            </select>
          </div>
          <div class="form-group">
            <label>Pilih Paket</label>
            <select name="paket_id" class="form-control">
              <option selected="">Pilih Paket</option>
              <?php foreach ($paket as $key): ?>
                <option value="<?= $key['id_paket'] ?>"><?= $key['jenis'] ?></option>
              <?php endforeach ?>
            </select>
          </div>
          <div class="form-group">
            <label>Berat</label>
            <input type="text" name="berat" class="form-control">
          </div>
          <div class="text-right">
            <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
          </div>
        </form>
      </div>
    </div>
    <div class="col-md-6">
        <div id="pesan" ></div>
        <div class="tombol text-right">
          <button type="button" class="btn btn-success btn-md " data-toggle="modal" data-target="#ModalTambah" ><span class="glyphicon glyphicon-plus " ></span> Tambah Pakaian</button>
        </div>
        <br>
        <div class="table-responsive">
          <table id="table" class="table table-striped table-bordered" >
            <thead>
              <tr>
                <th style="text-align: center;">Invoice</th>
                <th class="text-center">Jenis Pakaian</th>
                <th class="text-center">Jumlah Pakaian</th>
                <th style="text-align: center;" >Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $sql = mysqli_query($conn, "SELECT id_transaksi FROM tb_transaksi  ORDER BY id_transaksi Desc LIMIT 1");
                while ($hasil = mysqli_fetch_array($sql)){
                  $no = $hasil['id_transaksi'];
                }

                $no_o = $no + 1;
                $i = 0 + 1;
                $sql = mysqli_query($conn, "SELECT tb_pakaian.jenis_pakaian, tb_detail_transaksi.transaksi_id, tb_detail_transaksi.pakaian_id, tb_detail_transaksi.jumlah_pakaian FROM tb_detail_transaksi join tb_pakaian on tb_detail_transaksi.pakaian_id = tb_pakaian.id_pakaian Where transaksi_id = $no_o");
                while ($hasil = mysqli_fetch_array($sql)) {
                 ?>
                 <tr>
                  <td style="text-align: center;"><?= $no_o ?></td>
                  <td><?= $hasil['jenis_pakaian'] ?></td>
                  <td><?= $hasil['jumlah_pakaian'] ?></td>
                  <td style="text-align: center">
                    <a href="proses-hapus-detail-pakaian.php?order=<?php echo $hasil['transaksi_id']; ?>&pakaian=<?php echo $hasil['pakaian_id']; ?>" class="btn btn-danger">Hapus</a></td>
                  </tr>
                  <?php
                  $i++;
                }
                ?>

          </tbody>
        </table>
      </div>

    </div>
  </div>
  <!-- Modal Tambah Data -->
<div class="modal fade" id="ModalTambah" role="dialog">
 <div class="modal-dialog modal-sm">
  <!-- Modal content-->
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Tambah Transaksi Pakaian</h4>
  </div>

  <div class="modal-body">
    <form action="proses-tambah-pakaian-transaksi.php" method="POST" >
      <?php
      $sql = mysqli_query($conn, "SELECT id_transaksi FROM tb_transaksi ORDER BY id_transaksi Desc LIMIT 1");
      while ($hasil = mysqli_fetch_array($sql)){
        $na = $hasil['id_transaksi'];
      }
      ?>
      <input type="text" class="form-control" name="transaksi_id" value="<?php echo $na + 1;  ?>">
      <div class="form-group">
            <label>Jenis Pakaian</label>
            <select class="form-control" name="pakaian_id">
              <option>Pilih Jenis Pakaian</option>
              <?php
              $sql = mysqli_query($conn, "SELECT * FROM tb_pakaian ORDER BY jenis_pakaian");
              while ($hasil = mysqli_fetch_array($sql)){

                ?>
                <option value="<?=$hasil['id_pakaian'];?>"><?=$hasil['jenis_pakaian'];?></option>
                <?php
              }
              ?>
            </select>
          </div>
      <div class="form-group">
        <label>Jumlah Pakaian</label>
        <input type="text" class="form-control" name="jumlah">
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit" name="submit">Simpan</button>
        <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Batal</button>
      </div>
    </form>
  </div>
</div>
</div>
</div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>