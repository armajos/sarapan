<?php 
require 'fungsi.php';
$sql = "DELETE FROM tb_pakaian WHERE id_pakaian = " . $_GET['id'];
$exe = mysqli_query($conn,$sql);

if($exe){
        $_SESSION['pesan'] = "Hapus Data Pakaian Berhasil";
        header('Location: tambah-transaksi.php');
    }else{
        $_SESSION['pesan2'] = "Hapus Data Pakaian Gagal";
        header('Location: tambah-transaksi.php');
    }
 ?>