<?php 
require 'fungsi.php';
$Id_Pakaian = $_GET['pakaian'];
$No_Order = $_GET['order'];

if (isset($error)) {
	echo '<b>Error</b>: <br />'.implode('<br />', $error);
} else {
  $query = "DELETE FROM tb_detail_transaksi WHERE transaksi_id='".$No_Order."' AND pakaian_id='".$Id_Pakaian."'";
  $sql = mysqli_query($conn, $query);
?>
		<script type="text/javascript">setTimeout("location.href='tambah-transaksi.php?edit=<?php echo $No_Order ?>';");</script>
<?php
}
