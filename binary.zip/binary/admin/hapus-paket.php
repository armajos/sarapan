<?php 
require 'fungsi.php';
$sql = "DELETE FROM tb_paket WHERE id_paket = " . $_GET['id'];
$exe = mysqli_query($conn,$sql);

if($exe){
        $_SESSION['pesan'] = "Hapus Data Paket Berhasil";
        header('Location: paket.php');
    }else{
        $_SESSION['pesan2'] = "Hapus Data Paket Gagal";
        header('Location: paket.php');
    }
 ?>

