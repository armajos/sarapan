<?php
require 'fungsi.php';
ob_start();
$nama = 'Detail Transaksi';
require 'header.php';
$status = ['proses','selesai','diambil'];
$status_bayar = ['belum','lunas'];

$query = "SELECT tb_transaksi.*,tb_pelanggan.nama_pelanggan,tb_outlet.*,tb_outlet.nama_outlet,tb_paket.*,tb_paket.jenis FROM tb_transaksi INNER JOIN tb_pelanggan ON tb_pelanggan.id_pelanggan = tb_transaksi.pelanggan_id INNER JOIN tb_outlet ON tb_outlet.id_outlet = tb_transaksi.outlet_id INNER JOIN tb_paket ON tb_paket.outlet_id = tb_transaksi.outlet_id  WHERE tb_transaksi.id_transaksi=".$_GET['id'];

$data = ambilsatubaris($conn,$query);

if(isset($_POST['simpan'])){
  $status  = $_POST['status'];
  $status_bayar  = $_POST['status_bayar'];
  $query   = "UPDATE tb_transaksi SET status_transaksi = '$status', status_bayar =  '$status_bayar' WHERE id_transaksi = " . $_GET['id'];

  $execute = sukses($conn,$query);
  if($execute == 1){
    $_SESSION['pesan'] = "Edit Data Transaksi Berhasil";
    header('Location: transaksi.php');
  }else{
    $_SESSION['pesan2'] = "Edit Data Transaksi Gagal";
    header('Location: transaksi.php');
  }
}

?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
        <div class="col-md-6"><h2><?= $nama ?></h2></div>
        <div class="col-md-6 text-right"><h2><a href="transaksi.php"><i class="fa fa-arrow-left" title="kembali" style="color: red;"></i></a></h2></div>
      </div>
    </div>
    <!-- /. ROW  -->
    <hr />
    <?php 
    if (isset($_SESSION['pesan'])) {
      echo "<div class='alert alert-success' role='alert'>";
      echo $_SESSION['pesan'];
      unset($_SESSION['pesan']);
      echo "</div>";
      echo "<br/>";
    }elseif (isset($_SESSION['pesan2'])) {
      echo "<div class='alert alert-danger' role='alert'>";
      echo $_SESSION['pesan2'];
      unset($_SESSION['pesan2']);
      echo "</div>";
      echo "<br/>";
    }
    ?>
    <div class="row">
      <div class="col-md-6">
       <form method="post" action="">
              <div class="form-group">
                <label>Kode Invoice</label>
                <input type="text" name="kode_invoice" class="form-control" readonly="" value="<?= $data['id_transaksi'] ?>">
              </div>
              <div class="form-group">
                <label>Outlet</label>
                <input type="text" name="outlet" class="form-control" readonly="" value="<?= $data['nama_outlet'] ?>">
              </div>
              <div class="form-group">
                <label>Pelanggan</label>
                <input type="text" name="pelanggan" class="form-control" readonly="" value="<?= $data['nama_pelanggan'] ?>"> 
              </div>
              <div class="form-group">
                <label>Jenis Paket</label>
                <input type="text" name="paket" class="form-control" readonly="" value="<?= $data['jenis'] ?>"> 
              </div>
              <div class="form-group">
                <label>Berat</label>
                <input readonly=""   type="text" name="berat" class="form-control" value="<?= $data['berat'] ?> Kg"> 
              </div>
              <!-- <div class="form-group">
                <label>Total Harga</label>
                <input readonly=""   type="text" name="total_harga" class="form-control" value="<?= $data['total_harga'] ?>"> 
              </div> -->
              <?php if ($data['total_bayar'] > 0 ): ?>
                <div class="form-group">
                  <label>Total Bayar</label>
                  <input readonly=""   type="text" name="total_bayar" class="form-control" value="<?= $data['total_bayar'] ?>"> 
                </div>
                <div class="form-group">
                  <label>Tanggal Selesai</label>
                  <input readonly=""   type="text" name="tgl_selesai" class="form-control" value="<?= $data['tgl_selesai'] ?>"> 
                </div>
                <?php else: ?>
                  <div class="form-group">
                    <label>Total Bayar</label>
                    <input readonly=""   type="text" name="total_bayar" class="form-control" value="Belum Melakukan Pembayaran"> 
                  </div>
                  <div>
                  <?php  endif;?>
                  <div class="form-group">
                    <label>Status Transaksi</label>
                    <select name="status" class="form-control">
                      <?php foreach ($status as $key): ?>
                        <?php if ($key == $data['status_transaksi']): ?>
                          <option value="<?= $key ?>" selected><?= $key ?></option>
                        <?php endif ?>
                        <option ><?= $key ?></option>
                      <?php endforeach ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Status Bayar</label>
                    <select name="status_bayar" class="form-control">
                      <?php foreach ($status_bayar as $key): ?>
                        <?php if ($key == $data['status_bayar']): ?>
                          <option value="<?= $key ?>" selected><?= $key ?></option>
                        <?php endif ?>
                        <option ><?= $key ?></option>
                      <?php endforeach ?>
                    </select>
                  </div>
                  
                  
                  <div class="text-right">
                    <button type="submit" name="simpan" class="btn btn-primary">Edit</button>
                  </div>
                </form>
      </div>
    </div>

  </div>
  
  <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>