<?php
require 'fungsi.php';
$nama = 'Transaksi';
require 'header.php';
$query = "SELECT tb_transaksi.*,tb_pelanggan.nama_pelanggan FROM tb_transaksi INNER JOIN tb_pelanggan ON tb_pelanggan.id_pelanggan = tb_transaksi.pelanggan_id ";
$data = data($conn,$query);
$no =1;
?> 
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
        <h2><?= $nama ?></h2>

      </div>
    </div>
    <!-- /. ROW  -->
    <hr />
    <?php 
    if (isset($_SESSION['pesan'])) {
      echo "<div class='alert alert-success' role='alert'>";
      echo $_SESSION['pesan'];
      unset($_SESSION['pesan']);
      echo "</div>";
      echo "<br/>";
    }elseif (isset($_SESSION['pesan2'])) {
      echo "<div class='alert alert-danger' role='alert'>";
      echo $_SESSION['pesan2'];
      unset($_SESSION['pesan2']);
      echo "</div>";
      echo "<br/>";
    }
    ?>
    <div class="row">
      <!-- <div class="col-md-6">
        <a href="tambah-transaksi.php" class="btn btn-primary box-title btn-block"><i class="fa fa-plus fa-fw"></i> Tambah Transaksi</a>
      </div>
      <div class="col-md-6">
        <a href="konfirmasi-transaksi.php" class="btn btn-primary box-title btn-block"><i class="fa fa-check fa-fw"></i> Konfirmasi Pembayaran</a>
      </div>  -->
      <div class="col-md-12">
        <a href="tambah-transaksi.php" class="btn btn-primary btn-block"><i class="fa fa-plus fa-lg"></i></a>
        <!-- Advanced Tables -->
        <div class="panel panel-default">
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered table-hover" id="dataTables-example">
               <thead>                                 
                <tr>
                  <th class="text-center">No</th>
                  <th>Invoice</th>
                  <th>Pelanggan</th>
                  <th>Status Bayar</th>
                  <th>Status Transaksi</th>
                  <th>Total Bayar</th>
                  <th class="text-center">Aksi</th>
                </tr>
              </thead>
              <tbody>                                 
               <?php if (is_array($data)): ?>
                <?php $no=1; foreach($data as $transaksi): ?>
                <tr>
                  <td class="text-center"><?= $no++; ?></td>
                  <td><?= $transaksi['id_transaksi'] ?></td>
                  <td><?= $transaksi['nama_pelanggan'] ?></td>
                  <td><?= $transaksi['status_bayar'] ?></td>
                  <td><?= $transaksi['status_transaksi'] ?></td>
                  <td><b>Rp.</b><?= $transaksi['total_bayar'] ?></td>
                  <td align="center">
                    <a href="detail-transaksi.php?id=<?= $transaksi['id_transaksi']; ?>" data-toggle="tooltip" data-placement="bottom" title="Edit" class="btn btn-success btn-block">Detail</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
  <!--End Advanced Tables -->
</div>
</div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>