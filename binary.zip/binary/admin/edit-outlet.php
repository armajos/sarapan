<?php  
$nama = 'Edit Outlet';
require 'fungsi.php';
require 'header.php';

$id_outlet = $_GET['id'];
$queryedit = "SELECT * FROM tb_outlet WHERE id_outlet = '$id_outlet'";
$edit = ambilsatubaris($conn,$queryedit);

if(isset($_POST['simpan'])){
    $namaout  = $_POST['nama_outlet'];
    $alamat   = $_POST['alamat'];
    $telepon  = $_POST['telp'];
    $query = "UPDATE tb_outlet SET nama_outlet = '$namaout' , alamat = '$alamat' , telp = '$telepon' WHERE id_outlet = '$id_outlet'";

    $execute = sukses($conn,$query);
    if($execute == 1){
        $_SESSION['pesan'] = "Edit Data Outlet Berhasil";
        header('Location: outlet.php');
    }else{
        $_SESSION['pesan'] = "Edit Data Outlet Gagal";
    }
}
?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2><?= $nama ?></h2>
     </div>
   </div>
   <!-- /. ROW  -->
   <hr />
   <div class="row">
       <div class="col-md-12">
           <div class="white-box">
                <form method="post" action="">
                <div class="form-group">
                    <label>Nama Outlet</label>
                    <input type="text" value="<?= $edit['nama_outlet']; ?>" name="nama_outlet" class="form-control">
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <textarea name="alamat" class="form-control"><?= $edit['alamat']; ?></textarea>
                </div>
                <div class="form-group">
                    <label>Nomor Telepon</label>
                    <input type="text" value="<?= $edit['telp']; ?>" name="telp" class="form-control">
                </div>
                <div class="text-right">
                    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                </div>
                </form>
            </div>
       </div>
   </div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>