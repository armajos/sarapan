<?php 
$nama = 'Tambah Pengguna';
require 'fungsi.php';
require 'header.php';

$outlet = data($conn,'SELECT * FROM tb_outlet');
if (isset($_POST['simpan'])) {
  $namaus   = $_POST['nama_user'];
  $username = $_POST['username'];
  $password = md5($_POST['password']);
  $level    = $_POST['level'];
  if ($level = 'kasir') {
    $query = "INSERT INTO tb_user (nama_user,username,password,level) values ('$namaus','$username','$password','$level')";
  }else{
    $query = "INSERT INTO tb_user (nama_user,username,password,role) values ('$namaus','$username','$password','$level')";
  }
  $hasil = sukses($conn,$query);
  if($hasil == 1){
    $_SESSION['pesan'] = "Tambah Data Pengguna Berhasil";
    header('Location: pengguna.php');
  }else{
    $_SESSION['pesan'] = "Tambah Data Pengguna Gagal";
  }
}
?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2><?= $nama ?></h2>
     </div>
   </div>
   <!-- /. ROW  -->
   <hr />
   <div class="row">
       <div class="col-md-12">
           <div class="white-box">
                <form method="post" action="">
              <div class="form-group">
                <label>Nama Pengguna</label>
                <input type="text" name="nama_user" class="form-control">
              </div>
              <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control">
              </div>
              <div class="form-group">
                <label>Password</label>
                <input type="text" name="password" class="form-control">
              </div>
              <div class="form-group">
                <label>Level</label>
                <select name="role" class="form-control">
                  <option selected="">Pilih Salah Satu</option>
                  <option value="admin">Admin</option>
                  <option value="owner">Owner</option>
                  <option value="kasir">Kasir</option>
                </select>
              </div>
              <div class="text-right">
                <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
              </div>
            </form>
            </div>
       </div>
   </div>

</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php  
require 'footer.php';
?>