<?php 
require 'fungsi.php';
$sql = "DELETE FROM tb_outlet WHERE id_outlet = " . $_GET['id'];
$exe = mysqli_query($conn,$sql);

if($exe){
        $_SESSION['pesan'] = "Hapus Data Outlet Berhasil";
        header('Location: outlet.php');
    }else{
        $_SESSION['pesan'] = "Hapus Data Outlet Gagal";
    }
 ?>